    #ifndef _ARBRE_AVL_H
    #define _ARBRE_AVL_H
    #include<iostream>
    #include <fstream>
    #include<cstdio>
    #include<iomanip>
    #include<sstream>
    #include<algorithm>
    #include <string>
    #include <cstdlib>
    #include <vector>
    #include "Outils.h"
    using namespace std;
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Classe Noeud--------------------------------------------------------------------------------------------------------------------------------------------------
    /*
    *La classe Noeud définit les caractéristique d'un noeud d'un arbre binaire de recherche
    *clef désigne la valeur(un double) de la clef du noeud 
    *valeur désigne une valeur double, autre que la valeur de la clef, associée au noeud
    *a désigne la valeur maximale entre les valeur du noeud courant avec les valeurs des noeuds de ses déscendants
    *gauche est un pointeur vers le fils gauche du noeud
    *droite est un pointeur vers le fils droit du noeud
    */
class Noeud {
public:
 double clef;
 double valeur;
 double a;
 Noeud *gauche;
 Noeud *droite;
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    /*
     *constructeur sans argument de Noeud, initialisant les pointeurs gauche et droite
     */ 
 Noeud(){
  gauche = droite = NULL ;
}
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    /*
     *constructeur de la classe Noeud
     */ 
Noeud(double v,double val, double val_max=0,Noeud *g = NULL, Noeud *d = NULL ):
clef(v),valeur(val), a(val_max),gauche(g), droite(d){} 
   //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    /*
     *caractérisation d'une feuille
     */ 
bool avlFeuille() const
{
  return ( gauche == NULL ) && ( droite == NULL ) ;
}             
}*r;
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Classe arbre_avl------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    /*
     *Classe Arbre_avl avec le prototype de toutes ses méthodes
     */ 
class Arbre_avl{
public:
  int Hauteur(Noeud *);
  int difference(Noeud *);
  Noeud *rotation_dd(Noeud *);
  Noeud *rotation_gg(Noeud *);
  Noeud *rotation_gd(Noeud*);
  Noeud *rotation_dg(Noeud *);
  Noeud * rotation(Noeud *);
  Noeud *pere(Noeud*,Noeud*);
  Noeud * insert(Noeud*, double, double);
  double a_(Noeud*);
  double mise_a_jour_a(Noeud*);
  double maxima(Noeud*);
  double maxima(Noeud*,double);
  double aGauche( Noeud*, double);
  string appartient(Noeud*,double);
  vector<pair<double, double>>jusqua(Noeud*,double);
  void avant(Noeud*,double);
  void Jusqua(Noeud*,double);
  Arbre_avl() {
   r = NULL;
}
};
 //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Calcul de la hauteur d'un noeud---------------------------------------------------------------------------------------------------------------------------------
    /*
     *Fonction Hauteur calcule la hauteur d'un noeud
     *@param t, le noeud dont cherche la hauteur
     *hauteur est la hauteur  du noeud en question. hauteur_gauche et hauteur_droite désignent respectivement les hauteur gauche et droite du noeud. hauteur_max est la plus grande
     des deux
     */ 
int Arbre_avl::Hauteur(Noeud *t) {
 int hauteur = 0;
 if(t != NULL) {
  int hauteur_gauche = Hauteur(t->gauche);
  int hauteur_droite = Hauteur(t->droite);
  int hauteur_max = max(hauteur_gauche, hauteur_droite);
  hauteur = hauteur_max + 1;
}
return hauteur;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Calcul du facteur d'équilibre-----------------------------------------------------------------------------------------------------------------------------------
    /*Fonction difference  calcule le facteur d'équilibre d'un noeud
     *@param t, le noeud dont cherche le facteur d'équilibre
     *fact_equilibre est le facteur d'équilibre du noeud en question. hauteur_gauche et hauteur_droite désignent respectivement les hauteur gauche et droite du noeud. 
     */ 
    
int Arbre_avl::difference(Noeud *t) {
 int hauteur_gauche = Hauteur(t->gauche);
 int hauteur_droite = Hauteur(t->droite);
 int fact_equilibre = hauteur_gauche - hauteur_droite;
 return fact_equilibre;
}


    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Rotation droite suivie d'une rotation droite--------------------------------------------------------------------------------------------------------------------
    /*Fonction rotation_dd  calcule effectue le changement de position entre deux noeuds comptant pour une rotation droite
     *@param parent, le noeud par rapport auquel la rotation sera effectuée
     *t le noeud échangé avec le fils droit du noeud parent. 
     */ 
Noeud *Arbre_avl::rotation_dd(Noeud *parent) {
 Noeud *t;
 t = parent->droite;
 parent->droite = t->gauche;
 t->gauche = parent;
 return t;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Rotation gauche suivie d'une rotation gauche--------------------------------------------------------------------------------------------------------------------
    /*Fonction rotation_gg  calcule effectue le changement de position entre deux noeuds comptant pour une rotation gauche
     *@param parent, le noeud par rapport auquel la rotation sera effectuée
     *t le noeud échangé avec le fils gauche du noeud parent. 
     */ 
Noeud *Arbre_avl::rotation_gg(Noeud *parent) {
 Noeud *t;
 t = parent->gauche;
 parent->gauche = t->droite;
 t->droite = parent;
 return t;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Rotation gauche suivie d'une rotation droite--------------------------------------------------------------------------------------------------------------------
    /*Fonction rotation_gd  calcule effectue le changement de position entre deux noeuds comptant pour une double rotation gauche-droite
     *@param parent, le noeud par rapport auquel la rotation sera effectuée
     *t le noeud échangé avec le fils gauche du noeud parent. 
     */ 
Noeud *Arbre_avl::rotation_gd(Noeud *parent) {
 Noeud *t;
 t = parent->gauche;
 parent->gauche = rotation_dd(t);
 return rotation_gg(parent);
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Rotation droite suivie d'une rotation gauche--------------------------------------------------------------------------------------------------------------------
    /*Fonction rotation_dg  calcule effectue le changement de position entre deux noeuds comptant pour une double rotation droite-gauche
     *@param parent, le noeud par rapport auquel la rotation sera effectuée
     *t le noeud échangé avec le fils droit du noeud parent. 
     */
Noeud *Arbre_avl::rotation_dg(Noeud *parent) {
 Noeud *t;
 t = parent->droite;
 parent->droite = rotation_gg(t);
 return rotation_dd(parent);
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Reéquilibrage---------------------------------------------------------------------------------------------------------------------------------------------------
    /*Fonction rotation  reéquilibre le sous arbre à partir du noeud t
     *@param t, le noeud par rapport auquel la rotation sera effectuée
     *fact_equilibre désigne le facteur d'équilibre du noeud t 
     */
Noeud *Arbre_avl::rotation(Noeud *t) {
 int fact_equilibre = difference(t);
 if (fact_equilibre > 1) {
  if (difference(t->gauche) > 0)
   t = rotation_gg(t);
else
   t = rotation_gd(t);
} else if (fact_equilibre < -1) {
  if (difference(t->droite) > 0)
   t = rotation_dg(t);
else
   t = rotation_dd(t);
}
return t;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Recherche du pere d'un noeud donné------------------------------------------------------------------------------------------------------------------------------
    /*Fonction pere renvoie le pere d'un noeud 
     *@param t racine de l'arbre, fils  le noeud dont on cherche le pere
     *fact_equilibre désigne le facteur d'équilibre du noeud t 
     *noeudpere est le noeud pere du noeud fils
     */
Noeud*Arbre_avl::pere(Noeud*t,Noeud*fils){
    Noeud* noeudpere;
    if(t==NULL){
        noeudpere=NULL;
    }
    else{
        if((t->gauche==fils)||(t->droite==fils)){
            noeudpere=t;

        }
        else{
            if(fils->clef<t->clef){
                noeudpere=pere(t->gauche,fils);
            }
            else{
                noeudpere=pere(t->droite,fils);
            }
        }
    }
    return noeudpere;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Maximum de deux réels-------------------------------------------------------------------------------------------------------------------------------------------
    /*Fonction max renvoie le maximum de deux valeurs doubles
     *@param n et m deux paramètres double dont on cherche le plus grand
     *sup le plus grand parmi n et m
     */
int max(double n,double m){
 double sup;
 if(n<m){
  sup = m;
}
else{
  sup = n;
}
return sup;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Calcul du maximum local des valeurs-----------------------------------------------------------------------------------------------------------------------------
    /*Fonction max renvoie le maximum local de l'instance valeur de chaque noeud i.e. la plus grande de l'instance valeur d'un noeud et celles de ses descendants
     *@param p paramètres Noeud dont on cherche le maximum local de sa valeur
     *rep est un boolean permettant de savoir si un noeud est feuille ou pas
     *val_vmax la valeur de retour i.e. le maximum local recherché
     */
double Arbre_avl::a_(Noeud*p){
    double val_max;
    bool rep = p->avlFeuille();
    if(rep == true){
       val_max = p->valeur;
   }
   else{
    if((p->gauche!=NULL)&&(p->droite==NULL)){
        val_max  = max(p->gauche->a,p->valeur);
    }
    else {
        if((p->droite!=NULL)&&(p->gauche==NULL)){
            val_max  = max(p->droite->a,p->valeur);
        }
        else{
            double val_inter = max(p->gauche->a,p->valeur);
            val_max = max(val_inter,p->droite->a);
        }
    }
}

return val_max;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Mise à jour de la valeur de a après insertion et rééquilibrage--------------------------------------------------------------------------------------------------
    /*Fonction mise_a_jour_a fait la mise à jour de la valeur de a pour un noeud r donné après le reéquilibrage de l'arbre
     *@param r paramètres Noeud dont on met à jour le a
     *val_vmax est la nouvelle valeur du noeud en question
     */
double Arbre_avl::mise_a_jour_a(Noeud*r){
    double val_max;
    if((r->gauche!=NULL)&&(r->droite!=NULL)){
       r->a =0;
       r->gauche->a = 0;
       r->droite->a = 0;
       r->gauche->a = a_(r->gauche);
       r->droite->a = a_(r->droite);
       val_max = a_(r);
   }
   else{
     if((r->gauche!=NULL)&&(r->droite==NULL)){
       r->a =0;
       r->gauche->a = 0;
       r->gauche->a = a_(r->gauche);
       val_max = a_(r);
   }
   else{

    if((r->gauche==NULL)&&(r->droite!=NULL)){
       r->a =0;
       r->droite->a = 0;
       r->droite->a = a_(r->droite);
       val_max = a_(r);
   }

}
}
return val_max;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Insertion d'une nouvelle noeud suivi du reéquilibrage-----------------------------------------------------------------------------------------------------------
    /*Fonction insert permet d'ajouter un nouveau noeud de l'arbre  suivi du reéquilibrage de ce dernier
     *@param r le noeud  à inserrer, v et val, respectivement la clef  et la valeur du noeud r
     */
Noeud *Arbre_avl::insert(Noeud *r, double v, double val) {
 if (r == NULL) {
  r = new Noeud;
  r->clef = v;
  r->valeur = val;
  r->a = a_(r);
  r->gauche = NULL;
  r->droite = NULL;
} else if (v< r->clef) {
  r->gauche = insert(r->gauche, v,val);
  r = rotation(r);
  r->a=mise_a_jour_a(r);
} else if (v >= r->clef) {
  r->droite = insert(r->droite, v,val);
  r = rotation(r);
  r->a=mise_a_jour_a(r);
       }


       return r;
   }
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour de la valeur a de la racine------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer la valeur de a de la racine
    *@param t la racine de l'arbre
    *la variable a_racine est le double retourné
    */
double Arbre_avl::maxima(Noeud* t){
    double a_racine;
    if(t != NULL){
        a_racine = t->a;
        return a_racine;
    }
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour de la valeur a d'un noeud quelconque---------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer la valeur de a d'un noeud quelconque
    *@param t le noeud en question, le double x est la clef du noeud t
    */
double Arbre_avl::maxima(Noeud* t, double x){
    if(t==NULL) return 0;
    if(x ==t->clef)return (t->a);
    if(x<=t->clef) return maxima(t->gauche, x);
    else return maxima(t->droite, x);
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------méthode aGauche-------------------------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer le maximum local des valeurs de a pour les noeuds inférieur ou égale à un double x donné
    *@param t la racine de l'arbre et x le double en question, par rapport auquel on compare les clefs
    *le double agauche est la valeur retournée
    */
double Arbre_avl::aGauche( Noeud*t, double x){
    double agauche;
    if(t==NULL){
        return  atof("-INFINITY");
    }
    if(x<=t->clef) return aGauche(t->gauche,x);
    else{
        if(t->gauche==NULL){
            agauche = max(t->valeur,aGauche(t->droite,x));
        }
        else{
           agauche =max(max(t->gauche->a,t->valeur),aGauche(t->droite,x));
       }
       return agauche;
   }
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------méthode appartient----------------------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer un string vrai ou faux, indiquant si un double x est dans l'intervalle formé par les valeurs de a possible relativement aux clefs inférieures ou égale à x
    *@param t désigne la racine de l'arbre et  x le double avec lequel on compare les clefs
    *le string reponse est la valeur retournée
    */
string Arbre_avl::appartient(Noeud*t, double x){
    string reponse;
    if(t==NULL){
       reponse="faux";
   }
   else{

    if(x<=aGauche(t,x)){
        reponse ="vrai";
    }
    else{
        reponse="faux";
    }
    return reponse;
}
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------méthode jusqua--------------------------------------------------------------------------------------------------------------------------------------------------
    /*
    *cette fonction renvoie un vector de pair (double,double) contenant des couples (a,b) de clefs plus petites qu'un double x ainsi que les valeurs de valeurs correspondantes
    *@param t désigne la racine de l'arbre x le double avec lequel on compare les clefs
    *le vector de pair Jusqua est la valeur retournée
    *cette fonction est inachévée puisqu'elle ne renvoie qu'une partie des couples
    */
vector<pair<double, double>> Arbre_avl::jusqua(Noeud*t,double x){
    vector<pair<double, double>>Jusqua;
    Noeud*courant;
    courant=t;
    while(courant!=NULL){
        if(x>courant->clef){
            Jusqua.push_back( make_pair(courant->clef,courant->valeur) );
        }
        courant=courant->gauche;
    }
    return Jusqua;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------méthode donnant le résultat de la commande avant ?--------------------------------------------------------------------------------------------------------------
    /*
    *cette fonction affiche le contenu du vector de pair (double,double) contenant des couples (a,b) de clefs plus petites qu'un double x ainsi que les valeurs de valeurs correspondantes
    *@param t désigne la racine de l'arbre x le double avec lequel on compare les clefs
    */
void Arbre_avl::avant(Noeud*t,double x){
    vector<pair<double, double>>Jusqua;
    vector <pair <double,double> >::iterator p = Jusqua.begin();
    Jusqua= jusqua(t,x);
    cout<<"[";
    for(p=Jusqua.begin(); p!= Jusqua.end();++p ){
      cout << "(" <<p->first  << "," << p->second << ")" <<" ";
  }
  cout<<"]"<<endl;
}

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Version Jusqua sans usage de vector affichage direct des couples (clef,valeur)----------------------------------------------------------------------------------
    /*
    *cette fonction affiche  les couples (double,double)  (a,b) de clefs plus petites qu'un double x ainsi que les valeurs de valeurs correspondantes
    *@param t désigne la racine de l'arbre x le double avec lequel on compare les clefs
    */
void Arbre_avl::Jusqua(Noeud *t,double x) {
 if (t == NULL)
  return;
Jusqua(t->gauche,x);
if(x>=t->clef){
  cout <<"(" <<t->clef<<","<<t->valeur<< ")"<<",";
}
Jusqua(t->droite,x);
}
  #endif