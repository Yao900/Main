    #include<iostream>
    #include <fstream>
    #include<cstdio>
    #include<iomanip>
    #include<sstream>
    #include<algorithm>
    #include <string>
    #include <cstdlib>
    #include <vector>
    #include "Outils.h"
    using namespace std;
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Fonction renvoyant un string sans espace à partir d'un autre string---------------------------------------------------------------------------------------------
    /*
    *ce code permet de supprimer des espace d'une variable du type string
    *@param commande, le string contenant d'eventuels espaces
    */
   string suppression_espace(string commande){
    commande.erase(remove_if(commande.begin(),commande.end(),::isspace),commande.end());
    return commande;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Controle de la commande insertion ( x1,x2 )---------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de controler la commande insertion
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *les variables parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point désignent respectivement la parenthèse ouvrante, parenthèse fermante, requete diminuée d'une parenthèse,
     requete diminuée de la partie avant la virgule y compris la virgule, la valeur de la clef, la valeur de valeur, le point après la parenthèses fermante.
    *long1 est la longueur de requete
    *long2 la longueur de reduire2
    *la variable reponse est le boolean retourné indiquant si la commande saisie répond aux critères de la commande d'insertion
    */
bool controle_insertion(string commande){
    string requete=suppression_espace(commande);
    int long1, long2, pos_virgule;
    string parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point;
    bool reponse = false;
    long1= requete.length();
    if(long1<6){
       reponse = false;
   }
   else{
    parenthese1= requete.substr(0,1);
    reduire1 = requete.erase(0,1);
    pos_virgule = reduire1.find(",");
    val_clef = reduire1.substr(0,pos_virgule);
    reduire2 = reduire1.erase(0,pos_virgule + 1);
    long2= reduire2.length();
    point= reduire2.substr(long2-1,1);
    parenthese2 = reduire2.substr(long2-2,1);
    val_valeur = reduire2.substr(0,long2-2);
    if((parenthese1 == "(")&&(parenthese2==")")&&(point==".")&&(pos_virgule>0)){
        reponse = true;
    }
    else{
        reponse= false;
    }
}
return reponse;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour x1 de la clef issue de la commande insertion ( x1,x2 )---------------------------------------------------------------------------------------------------
/*
    *ce code permet renvoie le premier double de la commande d'insertion
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *les variables parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point désignent respectivement la parenthèse ouvrante, parenthèse fermante, requete diminuée d'une parenthèse,
     requete diminuée de la partie avant la virgule y compris la virgule, la valeur de la clef, la valeur de valeur, le point après la parenthèses fermante.
    *long1 est la longueur de requete
    *long2 la longueur de reduire2
    *la variable val_double représente la valeur double à renvoyer
    */
double clef_isertion(string commande){
    string requete=suppression_espace(commande);
    double val_double;
    int long1, long2, pos_virgule;
    string parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point;
    long1= requete.length();
    parenthese1= requete.substr(0,1);
    reduire1 = requete.erase(0,1);
    pos_virgule = reduire1.find(",");
    val_clef = reduire1.substr(0,pos_virgule);
    reduire2 = reduire1.erase(0,pos_virgule + 1);
    long2= reduire2.length();
    point= reduire2.substr(long2-1,1);
    parenthese2 = reduire2.substr(long2-2,1);
    val_valeur = reduire2.substr(0,long2-2);
    val_double = atof(val_clef.c_str());
    return val_double;
}

    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour x2 de la valeur issue de la commande insertion ( x1,x2 )-------------------------------------------------------------------------------------------------
    /*ce code permet renvoie le deuxième double de la commande d'insertion
    *@param commande, le string représentant la commande
    **requete la commande diminuée d'espace
    *les variables parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point désignent respectivement la parenthèse ouvrante, parenthèse fermante, requete diminuée d'une parenthèse,
     requete diminuée de la partie avant la virgule y compris la virgule, la valeur de la clef, la valeur de valeur, le point après la parenthèses fermante.
    *long1 est la longueur requete 
    *long2 la longueur de reduire2
    *la variable val_double représente la valeur double à renvoyer
    */
double valeur_isertion(string commande){
    string requete=suppression_espace(commande);
    double val_double;
    int long1, long2, pos_virgule;
    string parenthese1, parenthese2, reduire1, reduire2, val_clef, val_valeur, point;
    long1= requete.length();
    parenthese1= requete.substr(0,1);
    reduire1 = requete.erase(0,1);
    pos_virgule = reduire1.find(",");
    val_clef = reduire1.substr(0,pos_virgule);
    reduire2 = reduire1.erase(0,pos_virgule + 1);
    long2= reduire2.length();
    point= reduire2.substr(long2-1,1);
    parenthese2 = reduire2.substr(long2-2,1);
    val_valeur = reduire2.substr(0,long2-2);
    val_double = atof(val_valeur.c_str());
    return val_double;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Controle de la commande max ?-----------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de controler la commande max ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *long1 est la longueur de requete
    *la variable reponse est le boolean retourné indiquant si la commande saisie répond aux critères de la commande max ?
    */
bool controle_max(string commande){
    string requete=suppression_espace(commande);
    bool reponse = false;
    int long1= requete.length();
    if(long1<4){
       reponse = false;
   }
   else{
    if((requete.substr(0,3)=="max")&&(requete.substr(3,1)=="?")){
        reponse = true;
    }
    else{
        reponse = false;
    }
}
return reponse;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Controle de la commande x ?-------------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de controler la commande appartient i.e. x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *long1 est la longueur de requete
    *la variable reponse est le boolean retourné indiquant si la commande saisie répond aux critères de la commande x ?
    */
bool controle_appartient(string commande){
    string requete=suppression_espace(commande);
    bool reponse = false;
    int long1= requete.length();
    if(long1<2){
       reponse = false;
   }
   else{
    if((requete.substr(long1-1,1)=="?")&&((requete.find("donne")!=0)&&(requete.find("avant")!=0))){
        reponse = true;
    }
    else{
        reponse = false;
    }
}
return reponse;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour de la valeur x de la commande x ?------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer la valeur x de la commande  x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *val_x est le string extrait de requete
    *long1 est la longueur de requete
    *la variable val_double est le double retournée
    */
double valeur_appartient(string commande){
    string requete=suppression_espace(commande);
    int long1= requete.length();
    string val_x = requete.substr(0,long1-1);
    double val_double = atof(val_x.c_str());
    return val_double;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Controle de la commande donne x ?-------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de controler la commande donne x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *long1 est la longueur de requete
    *la variable reponse est le boolean retourné indiquant si la commande saisie répond aux critères de la commande donne x ?
    */
bool controle_donne(string commande){
    string requete=suppression_espace(commande);
    bool reponse = false;
    int long1= requete.length();
    if(long1<7){
       reponse = false;
   }
   else{
    if((requete.substr(long1-1,1)=="?")&&(requete.substr(0,5)=="donne")){
        reponse = true;
    }
    else{
        reponse = false;
    }
}
return reponse;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour de la valeur x de la commande donne x ?------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer la valeur x de la commande donne x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *val_x est le string extrait de requete
    *long1 est la longueur de requete
    *la variable val_double est le double retournée
    */
double valeur_donne(string requete){
    int long1= requete.length();
    string val_x = requete.substr(5,long1-6);
    double val_double = atof(val_x.c_str());
    return val_double;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Controle de la commande avant x ?-------------------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de controler la commande avant x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *long1 est la longueur de requete
    *la variable reponse est le boolean retournée indiquant si la commande saisie répond aux critères de la commande avant x ?
    */
bool controle_avant(string commande){
    string requete=suppression_espace(commande);
    bool reponse = false;
    int long1= requete.length();
    if(long1<7){
       reponse = false;
   }
   else{
    if((requete.substr(long1-1,1)=="?")&&(requete.substr(0,5)=="avant")){
        reponse = true;
    }
    else{
        reponse = false;
    }
}
return reponse;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------retour de la valeur x de la commande avant x ?------------------------------------------------------------------------------------------------------------------
    /*
    *ce code permet de renvoyer la valeur x de la commande avant x ?
    *@param commande, le string représentant la commande
    *requete la commande diminuée d'espace
    *val_x est le string extrait de requete
    *long1 est la longueur de requete
    *la variable val_double est le double retournée
    */
double valeur_avant(string commande){
    string requete=suppression_espace(commande);
    int long1= requete.length();
    string val_x = requete.substr(5,long1-6);
    double val_double = atof(val_x.c_str());
    return val_double;
}
