/*
*TP2 INF3105 ETE_2019
*Date  12/07/2019
*@Auteur: AKAKPO Yao Ihébami
*Code permanent: AKAY03118309
*/
    #include<iostream>
    #include <fstream>
    #include<cstdio>
    #include<iomanip>
    #include<sstream>
    #include<algorithm>
    #include <string>
    #include <cstdlib>
    #include <vector>
    #include "Arbre_AVL.h"
    #include "Outils.h"
    using namespace std;
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-----------------------------------Programme principal---------------------------------------------------------------------------------------------------------------------------------------------
int main(int argc, char* argv[]){
 Arbre_avl Noeud;
 string commande;
//std::cout.precision(5);
 getline(cin,commande);  
 do{
    if(commande=="q."){
       exit(1);
   }
   else{
    if(controle_insertion(commande)==true){
        r = Noeud.insert(r,clef_isertion(commande),valeur_isertion(commande));
    }
    else{
        if(controle_max(commande)==true){
            cout<< Noeud.maxima(r)<<endl;
        }
        else{
            if(controle_appartient(commande)==true){
    //cout<<valeur_appartient(commande)<<endl;
                cout<< Noeud.appartient(r,valeur_appartient(commande))<<endl;
            }
            else{
                if(controle_avant(commande)==true){
    //Noeud.avant(r, valeur_avant(commande));
                    cout<<"[";
                    Noeud.Jusqua(r,valeur_avant(commande));
                    cout<<"]"<<endl;
                }

                else{
                    if(controle_donne(commande)==true){
                        cout<<Noeud.aGauche(r, valeur_donne(commande))<<endl;
                    }
                    else{
                        cout<<"erreur de commande"<<endl;
                        exit(1);
                    }
                }
            }
    //fin else4
        }
    //fin else3
    }
    //fin else2
}
    //fin else1
getline(cin,commande); 
}
while(commande!="q.");
return 0;

}
